package com.example.demo.controller;
import java.util.concurrent.atomic.AtomicLong;

import com.example.demo.model.user;
import com.example.demo.repository.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.*;
import com.example.demo.service.userService;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import org.springframework.boot.jackson.*;

import javax.annotation.Resource;

@RestController
@RequestMapping(value = "/login")
public class logincontroller {
    @Autowired
    private userService userservice;

    @PostMapping("/check")
    @ResponseBody
    public JSONObject login(@RequestBody JSONObject loginuser) {
        JSONObject result = new JSONObject();
        user temp = userservice.check(loginuser.get("username").toString());
        if (temp == null || !temp.getPassword().equals(loginuser.get("password").toString())) {
            result.put("data", "false");

        } else {
            result.put("data", "true");
            result.put("name",temp.getName());
            result.put("username",temp.getUsername());
            result.put("password",temp.getPassword());
        }
        return result;
    }
    @PostMapping("/regist")
    @ResponseBody
    public String regist(@RequestBody JSONObject registuser) {
        userservice.regist(registuser.get("username").toString(),registuser.get("password").toString());
      return "success";
    }
}