package com.example.demo.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.model.transaction;
import com.example.demo.service.transactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.List;

@RestController
@RequestMapping(value = "/bill")
public class billcontroller {
    @Autowired
    transactionService transactionservice;
    @GetMapping("/getAll")
    public List<transaction> getAll(){
        return transactionservice.getAll();
    }
    @PostMapping("/add")
    @ResponseBody
    public String addBill(@RequestBody JSONObject bill){
    transaction temp = new transaction();
     temp.setTdate(new Date(System.currentTimeMillis()));
     temp.setTdetails(bill.getString("tdetails"));
     temp.setTtype(bill.getString("ttype"));
     temp.setTprice(bill.getDouble("tprice"));
     temp.setTpost(bill.getString("tpost"));
     temp.setToriginplace(bill.getString("toriginplace"));
     temp.setTfinalplace(bill.getString("tfinalplace"));
     temp.setTname(bill.getString("tname"));
     temp.setTisfinish(bill.getInteger("tisfinish"));
     temp.setTid(0);
     transactionservice.addBill(temp);
     return "yes";
    }
    @PostMapping("/getbill")
    @ResponseBody
    public String getBill(@RequestBody JSONObject bill){
        System.out.println(bill);
transactionservice.getBill(bill.getString("tget"),bill.getInteger("tid"));
return "yes";
    }

    @PostMapping("/mybill0")
    @ResponseBody
    public List<transaction> myBill0(@RequestBody JSONObject bill){
        System.out.println(bill);
        return transactionservice.mybill0(bill.getString("username"),bill.getString("username"));

    }
    @PostMapping("/mybill1")
    @ResponseBody
    public List<transaction> myBill1(@RequestBody JSONObject bill){
        System.out.println(bill);
        return transactionservice.mybill1(bill.getString("username"));

    }
    @PostMapping("/mybill2")
    @ResponseBody
    public List<transaction> myBill2(@RequestBody JSONObject bill){
        System.out.println(bill);
       return transactionservice.mybill2(bill.getString("username"));

    }
}
