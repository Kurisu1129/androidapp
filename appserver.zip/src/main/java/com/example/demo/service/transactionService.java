package com.example.demo.service;

import com.example.demo.model.transaction;
import com.example.demo.repository.transactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class transactionService {
    @Autowired
    transactionRepository transactionrepository;

    @Transactional
    public List<transaction> getAll(){
        return transactionrepository.findByTisfinishAndTget(0,null);
    }
    @Transactional
    public void addBill(transaction t){
        transactionrepository.save(t);
    }
    @Transactional
    public void getBill(String tget,Integer tid){
        transactionrepository.updateNameById(tget,tid);
    }
    @Transactional
    public List<transaction> mybill0(String tget,String tpost){
        return transactionrepository.findByTgetOrTpost(tpost,tget);
    }
    @Transactional
    public List<transaction> mybill1(String tget){
        return transactionrepository.findByTget(tget);
    }
    @Transactional
    public List<transaction> mybill2(String tpost){
        return transactionrepository.findByTpost(tpost);
    }

}
