package com.example.demo.service;
import javax.annotation.Resource;

import javax.transaction.Transactional;


import com.example.demo.model.user;
import com.example.demo.repository.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class userService {
    @Autowired
    private userRepository userrepository;

    @Transactional
    public  void saveUser(user u){
        userrepository.save(u);

    }

    @Transactional
    public user check(String username){

        System.out.println(username);
           user u=userrepository.findByUsername(username).get(0);
           System.out.println(u.getPassword());

       return u;
    }
    @Transactional
    public String regist(String username,String password){
 user temp = new user(username,password,0,username);
        userrepository.save(temp);
        return "success";
    }
}