package com.example.demo.service;




import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArraySet;

@ServerEndpoint("/websocket/{username}")
@Component
public class WebSocketServer {
    private Session session;
    private static Map<String, Session> sessionPool = new HashMap<>();
    private static Map<String, String> sessionIds = new HashMap<>();

    private static Map<String, TreeSet<String>> remainingMessagePool = new HashMap<>(128);

    /**
     * 用户连接时触发
     *
     * @param session
     * @param username
     */
    @OnOpen
    public void open(Session session, @PathParam(value = "username") String username) {
        System.out.println("用户"+username +"连接成功");
        this.session = session;
        sessionPool.put(username, session);
        sessionIds.put(session.getId(), username);
        // 离线消息发送
        if (remainingMessagePool.get(username) != null) {
            TreeSet<String> remainingMessages = remainingMessagePool.get(username);
            remainingMessages.forEach(it -> sendMessage(it, username));
            remainingMessagePool.remove(username);
        }
    }

    /**
     * 收到信息时触发
     *
     * @param message
     */
    @OnMessage
    public void onMessage(String message) {
        System.out.println("发送人:" + sessionIds.get(session.getId()) + "内容:" + message);
        JSONObject content = JSONObject.parseObject(message);
    }

    /**
     * 连接关闭触发
     */
    @OnClose
    public void onClose() {
        sessionPool.remove(sessionIds.get(session.getId()));
        sessionIds.remove(session.getId());
    }

    /**
     * 发生错误时触发
     *
     * @param session
     * @param error
     */
    @OnError
    public void onError(Session session, Throwable error) {
        error.printStackTrace();
    }

    /**
     * 信息发送的方法
     *
     * @param message
     * @param username
     */
    public static void sendMessage(String message, String username) {
        Session s = sessionPool.get(username);
        if (s != null) {
            try {
                s.getBasicRemote().sendText(message);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // 离线消息存储
            if (remainingMessagePool.get(username) != null) {
                TreeSet<String> remainingMessages = remainingMessagePool.get(username);
                remainingMessages.add(message);
            } else {
                TreeSet<String> remainingMessages = new TreeSet<>();
                remainingMessages.add(message);
                remainingMessagePool.put(username, remainingMessages);
            }
        }
    }

    /**
     * 获取当前连接数
     *
     * @return
     */
    public static int getOnlineNum() {
        return sessionPool.size();
    }

    /**
     * 获取在线用户名以逗号隔开
     *
     * @return
     */
    public static String getOnlineUsers() {
        StringBuffer users = new StringBuffer();
        for (String key : sessionIds.keySet()) {
            users.append(sessionIds.get(key) + ",");
        }
        return users.toString();
    }

    /**
     * 信息群发
     *
     * @param msg
     */
    public static void sendAll(String msg) {
        for (String key : sessionIds.keySet()) {
            sendMessage(msg, sessionIds.get(key));
        }
    }

    /**
     * 多个人发送给指定的几个用户
     *
     * @param msg
     * @param persons 用户s
     */

    public static void SendMany(String msg, String[] persons) {
        for (String userid : persons) {
            sendMessage(msg, userid);
        }

    }

}

