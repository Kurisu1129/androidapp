package com.example.demo.repository;
import com.example.demo.model.transaction;
import com.example.demo.model.user;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.cdi.JpaRepositoryExtension;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface transactionRepository extends JpaRepository<transaction,Integer> {
    List<transaction> findByTisfinishAndTget(@Param("tisfinish") Integer tisfinish,@Param("tget") String tget);
    @Modifying
    @Query(value = "update transaction set tget = :tget where tid = :tid",nativeQuery = true)
    void updateNameById(@Param("tget") String tget, @Param("tid") Integer tid);

    List<transaction> findByTgetOrTpost(@Param("tget") String tpost,@Param("tpost") String tget);
    List<transaction> findByTget(@Param("tget") String tpost);
    List<transaction> findByTpost(@Param("tpost") String tget);
}
