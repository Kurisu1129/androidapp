package com.example.demo.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.sql.Date;

@Entity
public class transaction {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer tid;
    private String tname;
    private Date tdate;
    private Integer tisfinish;
    private Double tprice;
    private String tfinalplace;
    private String toriginplace;
    private String tdetails;
    private String tpost;
    private String tget;
    private String ttype;

    public String getTtype() {
        return ttype;
    }

    public void setTtype(String ttype) {
        this.ttype = ttype;
    }

    public String getTget() {
        return tget;
    }

    public String getTpost() {
        return tpost;
    }

    public void setTpost(String tpost) {
        this.tpost = tpost;
    }

    public void setTget(String tget) {
        this.tget = tget;
    }

    public Date getTdate() {
        return tdate;
    }

    public Integer getTid() {
        return tid;
    }

    public Double getTprice() {
        return tprice;
    }

    public Integer getTisfinish() {
        return tisfinish;
    }

    public String getTdetails() {
        return tdetails;
    }

    public String getTfinalplace() {
        return tfinalplace;
    }

    public String getTname() {
        return tname;
    }

    public String getToriginplace() {
        return toriginplace;
    }

    public void setTdate(Date tdate) {
        this.tdate = tdate;
    }

    public void setTdetails(String tdetails) {
        this.tdetails = tdetails;
    }

    public void setTfinalplace(String tfinalplace) {
        this.tfinalplace = tfinalplace;
    }

    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public void setTisfinish(Integer tisfinish) {
        this.tisfinish = tisfinish;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public void setToriginplace(String toriginplace) {
        this.toriginplace = toriginplace;
    }

    public void setTprice(Double tprice) {
        this.tprice = tprice;
    }

}
